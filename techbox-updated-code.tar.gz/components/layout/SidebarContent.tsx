"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Moon, Sun, Bell, Search, Clock, ShoppingCart } from "lucide-react";
import { navItems, linkBase, linkInactive, isActive } from "@/config/sidebar.config";
import { SidebarContentProps } from "@/types/sidebar.types";
import SidebarTooltip from "@/components/layout/SidebarTooltip";
import { useEffect, useMemo, useState } from "react";
import { getCurrentUserClient, type AppUser } from "@/lib/auth";
import { useCart } from "@/providers/cart.provider";
import { getAllAcross } from "@/lib/content";
import { zIndex } from "@/design";

function TehranDateTime({ now, expanded }: { now: Date | null; expanded: boolean }) {
  if (!now) return null;

  if (!expanded) {
    return (
      <SidebarTooltip
        enabled
        label={`${now.toLocaleDateString("fa-IR", { timeZone: "Asia/Tehran" })} – ${now.toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Tehran" })} تهران`}
      >
        <span className="icon-rail-btn" aria-label="ساعت تهران">
          <Clock size={18} />
        </span>
      </SidebarTooltip>
    );
  }

  return (
    <div className="rounded-[var(--tb-radius-lg)] border border-[var(--tb-border)] bg-[var(--tb-muted)] px-3 py-2 text-center shadow-[var(--tb-shadow-sm)]">
      <div className="text-[10px] text-[var(--tb-muted-foreground)]">
        {now.toLocaleDateString("fa-IR", { weekday: "long", timeZone: "Asia/Tehran" })}
      </div>
      <div className="text-[11px] font-bold tabular-nums" dir="ltr">
        {now.toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit", second: "2-digit", timeZone: "Asia/Tehran" })}
      </div>
      <div className="text-[10px] text-[var(--tb-muted-foreground)]">
        {now.toLocaleDateString("fa-IR", { year: "numeric", month: "long", day: "numeric", timeZone: "Asia/Tehran" })}
      </div>
    </div>
  );
}

export default function SidebarContent({
  expanded,
  theme,
  onToggleTheme,
  onLogoClick,
  onLinkClick,
}: SidebarContentProps) {
  const pathname = usePathname();
  const router = useRouter();
  const [user, setUser] = useState<AppUser | null>(null);
  const [q, setQ] = useState("");
  const [now, setNow] = useState<Date | null>(null);
  const [notifOpen, setNotifOpen] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const { count: cartCount, setOpen: setCartOpen } = useCart();

  useEffect(() => {
    setUser(getCurrentUserClient());
    setNow(new Date());
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const h = () => setUser(getCurrentUserClient());
    window.addEventListener("storage", h);
    return () => window.removeEventListener("storage", h);
  }, []);

  const notifications = useMemo(() => getAllAcross().slice(0, 6), []);

  const doSearch = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (q.trim()) {
      router.push(`/search?q=${encodeURIComponent(q.trim())}`);
      onLinkClick?.();
    }
  };

  return (
    <div className="relative flex h-full w-full flex-col text-[13px]" dir="rtl">
      <header className="shrink-0 space-y-3 p-3">
        <div className="flex items-center gap-2">
          <div className="relative h-10 w-10 shrink-0">
            {onLogoClick ? (
              <SidebarTooltip label="باز/بستن منو" enabled={!expanded}>
                <button onClick={onLogoClick} className="relative h-10 w-10 overflow-hidden rounded-[var(--tb-radius-lg)] transition-opacity hover:opacity-90" aria-label="toggle sidebar">
                  <Image src="/logo.png" alt="تکباکس" fill sizes="40px" className="object-contain" />
                </button>
              </SidebarTooltip>
            ) : (
              <Image src="/logo.png" alt="تکباکس" fill sizes="40px" className="object-contain" />
            )}
          </div>

          <div className={`overflow-hidden transition-all duration-[var(--tb-duration-normal)] ${expanded ? "max-w-[170px] opacity-100" : "max-w-0 opacity-0"}`}>
            <div className="text-[14px] font-black leading-tight text-[var(--tb-foreground)]">تکباکس</div>
            <div className="text-[10px] leading-tight text-[var(--tb-muted-foreground)]">پاتوق بچه‌های فناوری اطلاعات</div>
          </div>

          <div className="ms-auto flex items-center gap-1">
            <div className="relative">
              <SidebarTooltip label="اعلان‌ها" enabled={!expanded}>
                <button onClick={() => setNotifOpen((o) => !o)} className="icon-rail-btn relative" aria-label="notifications">
                  <Bell size={18} />
                  <span className="absolute left-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-[var(--tb-danger)]" />
                </button>
              </SidebarTooltip>

              {notifOpen && (
                <div
                  className="fixed right-3 top-20 w-[320px] max-w-[92vw] p-3 text-right sm:absolute sm:right-0 sm:top-10 card"
                  style={{ zIndex: zIndex.popover }}
                >
                  <div className="mb-2 text-[12px] font-bold">آخرین رویدادها</div>
                  <ul className="max-h-80 space-y-2 overflow-y-auto text-[11px]">
                    {notifications.map((n: any) => (
                      <li key={n.slug} className="border-b border-border/40 pb-2 last:border-0">
                        <Link href={`/${n.module}/${n.slug}`} onClick={() => setNotifOpen(false)} className="line-clamp-2 leading-5 hover:text-brand">
                          {n.title}
                        </Link>
                        <div className="mt-0.5 text-[10px] text-[var(--tb-muted-foreground)]">{n.date_fa} • {n.module}</div>
                      </li>
                    ))}
                  </ul>
                  <button onClick={() => setNotifOpen(false)} className="mt-2 w-full text-center text-[10px] text-muted-foreground hover:text-foreground">بستن</button>
                </div>
              )}
            </div>

            <SidebarTooltip label={cartCount > 0 ? `سبد خرید – ${cartCount} قلم` : "سبد خرید"} enabled={!expanded}>
              <button onClick={() => setCartOpen(true)} className="icon-rail-btn relative" aria-label="سبد خرید">
                <ShoppingCart size={18} />
                {cartCount > 0 && (
                  <span className="absolute -left-0.5 -top-0.5 flex h-[16px] min-w-[16px] items-center justify-center rounded-full bg-[var(--tb-shop)] px-1 text-[9px] font-bold text-black">
                    {cartCount > 99 ? "۹۹+" : cartCount.toLocaleString("fa-IR")}
                  </span>
                )}
              </button>
            </SidebarTooltip>
          </div>
        </div>

        <TehranDateTime now={now} expanded={expanded} />

        {expanded ? (
          <form onSubmit={doSearch} className="relative">
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجو در تکباکس…" className="input !py-2 pe-8 text-xs" />
            <button type="submit" className="absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" aria-label="search">
              <Search size={14} />
            </button>
          </form>
        ) : (
          <SidebarTooltip label="جستجو" enabled>
            <button onClick={() => { const v = prompt("جستجو:"); if (v) router.push(`/search?q=${encodeURIComponent(v)}`); }} className="icon-rail-btn">
              <Search size={18} />
            </button>
          </SidebarTooltip>
        )}

        {expanded ? (
          <Link href="/consultation" onClick={onLinkClick} className="vip-cta block w-full py-2.5 text-center text-[12px] font-black">
            مشاوره VIP ⚡
          </Link>
        ) : (
          <SidebarTooltip label="مشاوره VIP" enabled>
            <Link href="/consultation" onClick={onLinkClick} className="icon-rail-btn text-[var(--tb-vip)] hover:text-[var(--tb-vip)]">
              <span className="text-[16px]">⚡</span>
            </Link>
          </SidebarTooltip>
        )}

        <SidebarTooltip label={theme === "dark" ? "حالت روز" : "حالت شب"} enabled={!expanded}>
          <button type="button" onClick={onToggleTheme} className="group flex h-10 w-full items-center rounded-[var(--tb-radius-lg)] text-[11px] text-muted-foreground transition-colors hover:bg-[var(--tb-muted)] hover:text-foreground">
            <span className="relative flex h-10 w-10 shrink-0 items-center justify-center">
              <Sun className={`absolute h-[18px] w-[18px] transition-all ${theme === "dark" ? "scale-100 text-[var(--tb-warning)] opacity-100" : "scale-0 opacity-0"}`} />
              <Moon className={`absolute h-[18px] w-[18px] transition-all ${theme === "dark" ? "scale-0 opacity-0" : "scale-100 opacity-100"}`} />
            </span>
            <span className={`overflow-hidden whitespace-nowrap text-[11px] transition-all ${expanded ? "max-w-[120px] opacity-100" : "max-w-0 opacity-0"}`}>
              {theme === "dark" ? "حالت روز" : "حالت شب"}
            </span>
          </button>
        </SidebarTooltip>

        <div className="border-t border-[var(--tb-border)]" />
      </header>

      <nav className="flex-1 overflow-y-auto px-2 py-1">
        <div className="flex flex-col gap-[2px]">
          {navItems.map((item) => {
            const Icon = item.icon as any;
            const active = isActive(pathname, item.href);
            const iconClass = active ? item.iconActiveClassName || "text-primary" : item.iconClassName || "text-muted-foreground";
            return (
              <SidebarTooltip key={item.href} label={item.title} enabled={!expanded}>
                <Link
                  href={item.href}
                  onClick={onLinkClick}
                  className={`${linkBase} ${active ? "text-foreground" : linkInactive}`}
                  style={{ background: active ? "var(--tb-muted)" : "transparent", fontSize: "13px" }}
                >
                  {active && <span className="absolute bottom-[8px] right-0 top-[8px] w-[3px] rounded-full bg-[var(--tb-brand)]" />}
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center">
                    <Icon size={19} className={iconClass} strokeWidth={1.75} />
                  </span>
                  <span className={`truncate transition-all ${expanded ? "max-w-[160px] opacity-100" : "max-w-0 opacity-0"}`}>{item.title}</span>
                </Link>
              </SidebarTooltip>
            );
          })}
        </div>
      </nav>

      <div className="shrink-0 space-y-2 border-t border-[var(--tb-border)] px-2 py-2">
        {user ? (
          <Link href="/account" onClick={onLinkClick} className={`${linkBase} ${isActive(pathname, "/account") ? "" : linkInactive}`} style={{ fontSize: "12px", background: isActive(pathname, "/account") ? "var(--tb-muted)" : "transparent" }}>
            <span className="flex h-10 w-10 shrink-0 items-center justify-center">
              <img src={user.avatar || "/assets/hooman.png"} alt={user.name} width={28} height={28} className="rounded-full object-cover ring-1 ring-[var(--tb-border)]" />
            </span>
            <span className={`truncate leading-tight ${expanded ? "max-w-[140px] opacity-100" : "max-w-0 opacity-0"} overflow-hidden transition-all`}>
              <span className="block text-[12px] font-bold">{user.name}</span>
              <span className="block text-[10px] text-[var(--tb-muted-foreground)]">{user.role === "super_admin" ? "مدیر کل" : "ویراستار"}</span>
            </span>
          </Link>
        ) : (
          <SidebarTooltip label="ورود / حساب کاربری" enabled={!expanded}>
            <button onClick={() => setLoginOpen(true)} className={`${linkBase} ${linkInactive} w-full`} style={{ fontSize: "12px" }}>
              <span className="flex h-10 w-10 items-center justify-center">
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[var(--tb-muted)] text-[11px]">👤</span>
              </span>
              <span className={`${expanded ? "max-w-[120px] opacity-100" : "max-w-0 opacity-0"} truncate transition-all`}>ورود</span>
            </button>
          </SidebarTooltip>
        )}
      </div>

      {loginOpen && (
        <div className="fixed inset-0 flex items-center justify-center p-4" style={{ zIndex: zIndex.modal }} dir="rtl">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-[var(--tb-blur-sm)]" onClick={() => setLoginOpen(false)} />
          <div className="relative w-full max-w-sm space-y-3 p-5 card" style={{ zIndex: zIndex.modalContent }}>
            <div className="flex items-center justify-between">
              <h3 className="text-[15px] font-black">ورود به تکباکس</h3>
              <button onClick={() => setLoginOpen(false)} className="text-muted-foreground hover:text-foreground">✕</button>
            </div>
            <p className="text-[11px] text-[var(--tb-muted-foreground)]">
              حساب تست: <b>sara</b> / <b>nima</b> / <b>rojina</b> / <b>admin</b><br />رمز همه: <code>techbox123</code>
            </p>
            <a href="/admin/login" onClick={() => setLoginOpen(false)} className="btn btn-primary w-full text-[13px]">رفتن به ورود کامل →</a>
            <button onClick={() => setLoginOpen(false)} className="btn btn-ghost w-full text-[11px]">بستن</button>
          </div>
        </div>
      )}
    </div>
  );
}
