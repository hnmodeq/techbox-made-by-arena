# Updated files for TechBox

Copy these files into your real project. Do **not** replace your `public/` folder from this workspace; your real binary fonts/images were not included in the text upload.

## Config / project files
- package.json
- tsconfig.json
- pnpm-workspace.yaml
- next.config.mjs
- next-env.d.ts
- postcss.config.mjs
- .env.example
- .gitignore

## Design tokens / styles
- design/index.ts
- design/tokens/colors.css
- design/tokens/z-index.ts
- design/foundation/globals.css
- design/foundation/primitives.css

## Sidebar / layout / UI
- components/layout/SidebarContent.tsx
- components/layout/SidebarShell.tsx
- components/layout/SidebarTooltip.tsx
- components/ui/Dropdown.tsx
- components/ui/Modal.tsx
- components/ui/Tooltip.tsx
- components/ui/Input.tsx
- components/ui/LikeButton.tsx

## Features/providers
- providers/cart.provider.tsx
- features/chat/components/Chatbot.tsx
- features/forum/components/ForumList.tsx
- features/blog/components/BlogGrid.tsx
- features/comment/components/CommentSection.tsx
- features/content/components/ContentCard.tsx
- features/tools/components/RaidCalculator.tsx
- features/tools/components/SubnetCalculator.tsx
- features/tools/components/ToolsGrid.tsx

## Config modules
- config/module-colors.ts
- config/sidebar.config.ts

## Notes
- `.env.local` was intentionally **not** created because it contains a sensitive Vercel token.
- Run `pnpm install`, then `pnpm typecheck`, then `pnpm build` in your real project.
